import type { PlanBlock } from "@/lib/types";
import {
  isConditioningPrescription,
  isIntervalPrescription,
  isRepsRangePrescription,
  isStrengthPrescription,
} from "@/lib/types";
import { formatDuration, formatLoad } from "@/lib/utils";

function typeBadgeCls(type: string): string {
  if (type.includes("main_lift") || type.includes("conditional_block"))
    return "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400";
  if (type.includes("accessory"))
    return "bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-400";
  if (type.includes("steady"))
    return "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400";
  if (type.includes("intervals"))
    return "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400";
  return "bg-gray-100 text-gray-600 dark:bg-slate-700 dark:text-slate-300";
}

interface BlockRowProps {
  block: PlanBlock;
}

export function BlockRow({ block }: BlockRowProps) {
  const rx = block.prescription;

  return (
    <div
      className="border-b border-gray-100 py-3 last:border-b-0 dark:border-slate-800"
      data-testid={`block-${block.block_id}`}
    >
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-gray-900 dark:text-slate-100">
          {block.exercise.name}
        </span>
        <span className={`rounded-md px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${typeBadgeCls(block.type)}`}>
          {block.type.replace(/_/g, " ")}
        </span>
      </div>
      <div className="mt-1.5 text-sm text-gray-500 dark:text-slate-400">
        {isStrengthPrescription(rx) && (
          <span data-testid="strength-rx" className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className="flex items-center gap-1">
              <span className="font-mono text-xs text-indigo-600 dark:text-indigo-400">TOP</span>
              {rx.top_set.reps}&times;{rx.top_set.sets} @ {formatLoad(rx.top_set.load_kg)}
              <span className="opacity-60">RPE {rx.top_set.target_rpe}</span>
            </span>
            {rx.backoff.length > 0 && (
              <span className="flex items-center gap-1">
                <span className="font-mono text-xs text-gray-400 dark:text-slate-500">BO</span>
                {rx.backoff[0].reps}&times;{rx.backoff[0].sets} @ {formatLoad(rx.backoff[0].load_kg)}
              </span>
            )}
          </span>
        )}
        {isRepsRangePrescription(rx) && (
          <span data-testid="reps-range-rx">
            {rx.sets} sets &times; {rx.reps_range[0]}-{rx.reps_range[1]} reps
            <span className="opacity-60"> @ RIR {rx.target_rir}</span>
          </span>
        )}
        {isConditioningPrescription(rx) && (
          <span data-testid="conditioning-rx">
            {formatDuration(rx.duration_minutes)}
            <span className="opacity-60"> &mdash; {rx.intensity.target}</span>
          </span>
        )}
        {isIntervalPrescription(rx) && (
          <span data-testid="interval-rx">
            {rx.work.intervals}&times;
            {rx.work.minutes_each ? `${rx.work.minutes_each}min` : `${rx.work.seconds_each}s`}
            <span className="opacity-60"> &mdash; {rx.work.intensity.target}</span>
          </span>
        )}
      </div>
    </div>
  );
}
